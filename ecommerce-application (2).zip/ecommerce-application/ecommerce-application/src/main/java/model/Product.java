package model;

public class Product {

    private int    productId;
    private String productName;
    private double productPrice;
    private int    productQuantity;
    private String productCategory;
    private String productDescription;   // FIX: was "productDescrpition" (typo)
    private String image;

    // ── image ──────────────────────────────────────────────────
    public String getImage()             { return image; }
    public void   setImage(String image) { this.image = image; }

    // ── productId ──────────────────────────────────────────────
    public int  getProductId()           { return productId; }
    public void setProductId(int id)     { this.productId = id; }

    // ── productName ────────────────────────────────────────────
    public String getProductName()               { return productName; }
    public void   setProductName(String name)    { this.productName = name; }

    // ── productPrice ───────────────────────────────────────────
    public double getProductPrice()              { return productPrice; }
    public void   setProductPrice(double price)  { this.productPrice = price; }

    // ── productQuantity ────────────────────────────────────────
    public int  getProductQuantity()             { return productQuantity; }
    public void setProductQuantity(int qty)      { this.productQuantity = qty; }

    // ── productCategory ────────────────────────────────────────
    public String getProductCategory()                   { return productCategory; }
    public void   setProductCategory(String category)    { this.productCategory = category; }

    // ── productDescription (typo fixed) ────────────────────────
    public String getProductDescription()                    { return productDescription; }
    public void   setProductDescription(String description)  { this.productDescription = description; }
}