package model;

public class Coupon {
	int CouponId;
	String CouponCode;
	String CouponCategory;
	int CouponDiscount;
	String CouponValidityDate;
	
	public Coupon(int CouponId, String CouponCode, String CouponCategory, int CouponDiscount, String CouponValidityDate) {
		this.CouponId=CouponId;
		this.CouponCode=CouponCode;
		this.CouponCategory=CouponCategory;
		this.CouponDiscount=CouponDiscount;
		this.CouponValidityDate=CouponValidityDate;
	}
	
	public int getCouponId() {return CouponId;}
	public String getCouponCode() {return CouponCode;}
	public String getCouponCategory() {return CouponCategory;}
	public int getCouponDiscount() {return CouponDiscount;}
	public String getCouponValidityDate() {return CouponValidityDate;}
}