package pages;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.ProductDAO;
import model.Product;

@WebServlet("/delete")
public class DeleteProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession();
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.trim().equals("a")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Product p = new Product();
            p.setProductId(id);

            ProductDAO dao = new ProductDAO();
            dao.delete(p);

            // ✅ FIX: redirect with success param so toast shows in dashboard
            response.sendRedirect(request.getContextPath()
                    + "/AdminDashboard?success=deleted");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath()
                    + "/AdminDashboard?error=error");
        }
    }
}