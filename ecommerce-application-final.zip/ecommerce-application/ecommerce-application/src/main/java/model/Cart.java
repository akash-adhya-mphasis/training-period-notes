package model;

public class Cart {
	int CartId;
	int ProductId;
	int UserId;
	
	public Cart(int CartId, int ProductId, int UserId) {
		this.CartId=CartId;
		this.ProductId=ProductId;
		this.UserId=UserId;
	}
}