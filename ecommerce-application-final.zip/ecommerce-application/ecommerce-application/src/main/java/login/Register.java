package login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import model.User;

@WebServlet("/register")
public class Register extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uname = request.getParameter("uname");
        String email = request.getParameter("email");
        String pass  = request.getParameter("pass");
        String cpass = request.getParameter("cpass");

        if (pass == null || !pass.equals(cpass)) {
            response.sendRedirect("register.jsp?error=password_mismatch");
            return;
        }

        if (pass.length() < 6) {
            response.sendRedirect("register.jsp?error=error");
            return;
        }

        HttpSession session = request.getSession();


        String otp = utils.OtpUtil.generateOTP();

       
        session.setAttribute("reg_uname", uname);
        session.setAttribute("reg_email", email);
        session.setAttribute("reg_pass", pass);
        session.setAttribute("reg_otp", otp);
        session.setAttribute("reg_otp_time", System.currentTimeMillis());

        // ✅ Send OTP email
        boolean sent = utils.EmailUtil.sendOTPForLoginEmail(
                email,
                "Verify your ShopEase Registration",
                otp
        );

        if (sent) {
            response.sendRedirect("register-otp.jsp");
        } else {
            response.sendRedirect("register.jsp?error=email_failed");
        }
    }
}
