package dao;

import java.sql.*;
import java.util.*;
import model.Product;

public class ProductDAO implements ProductDAOInterface {

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/e_commerce_app", "root", "root@39");
    }

    // ── Helper: ResultSet → Product ───────────────────────────
    private Product mapRow(ResultSet rs) throws Exception {
        Product p = new Product();
        p.setProductId(rs.getInt("p_id"));
        p.setProductName(rs.getString("p_name"));
        p.setProductCategory(rs.getString("category"));
        p.setProductDescription(rs.getString("description"));
        p.setProductQuantity(rs.getInt("quantity"));
        p.setProductPrice(rs.getDouble("price"));
        p.setImage(rs.getString("image"));
        return p;
    }

    
    @Override
    public boolean insert(Product p) {
        String sql = "INSERT INTO products (p_name, category, description, quantity, price, image) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getProductName());
            ps.setString(2, p.getProductCategory());
            ps.setString(3, p.getProductDescription());
            ps.setInt(4, p.getProductQuantity());
            ps.setDouble(5, p.getProductPrice());
            ps.setString(6, p.getImage());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public void update(Product p) {
        String sql = "UPDATE products SET p_name=?, category=?, description=?, " +
                     "quantity=?, price=?, image=? WHERE p_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getProductName());
            ps.setString(2, p.getProductCategory());
            ps.setString(3, p.getProductDescription());
            ps.setInt(4, p.getProductQuantity());
            ps.setDouble(5, p.getProductPrice());
            ps.setString(6, p.getImage());
            ps.setInt(7, p.getProductId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ────────────────────────────────────────────────
    @Override
    public void delete(Product p) {
        // Also remove from any carts first to avoid FK issues
        String deleteCart = "DELETE FROM cart WHERE p_id=?";
        String deleteProd = "DELETE FROM products WHERE p_id=?";
        try (Connection conn = getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(deleteCart)) {
                ps.setInt(1, p.getProductId()); ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(deleteProd)) {
                ps.setInt(1, p.getProductId()); ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── GET BY ID ─────────────────────────────────────────────
    @Override
    public Product getByProductId(int id) {
        String sql = "SELECT * FROM products WHERE p_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── GET ALL ───────────────────────────────────────────────
    @Override
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products ORDER BY category, p_name";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ── SEARCH ────────────────────────────────────────────────
    // Used by ShowUserProducts when ?q= param is present
    public List<Product> searchProducts(String query) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products " +
                     "WHERE p_name LIKE ? OR description LIKE ? OR category LIKE ? " +
                     "ORDER BY category, p_name";
        String like = "%" + query + "%";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}