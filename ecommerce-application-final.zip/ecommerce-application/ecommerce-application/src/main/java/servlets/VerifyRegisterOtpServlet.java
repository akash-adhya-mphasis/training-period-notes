package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class VerifyRegisterOtpServlet
 */
@WebServlet("/verifyRegisterOtp")
public class VerifyRegisterOtpServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String enteredOtp = request.getParameter("otp");
        String sessionOtp = (String) session.getAttribute("reg_otp");
        Long otpTime      = (Long) session.getAttribute("reg_otp_time");

        long currentTime = System.currentTimeMillis();
        long OTP_VALIDITY = 5 * 60 * 1000; // 5 minutes

        if (sessionOtp != null && otpTime != null) {

            if (currentTime - otpTime > OTP_VALIDITY) {
                response.sendRedirect("register.jsp?error=expired");
                return;
            }

            if (sessionOtp.equals(enteredOtp)) {

                // ✅ Now insert user in DB
                model.User u = new model.User();
                u.setUserName((String) session.getAttribute("reg_uname"));
                u.setUserEmail((String) session.getAttribute("reg_email"));
                u.setUserPassword((String) session.getAttribute("reg_pass"));
                u.setUserType("c");

                dao.UserDAO dao = new dao.UserDAO();
                boolean success = dao.insert(u);

                if (success) {

                    // Clear session data
                    session.removeAttribute("reg_uname");
                    session.removeAttribute("reg_email");
                    session.removeAttribute("reg_pass");
                    session.removeAttribute("reg_otp");
                    session.removeAttribute("reg_otp_time");

                    response.sendRedirect("login.jsp?info=registered");
                } else {
                    response.sendRedirect("register.jsp?error=email_exists");
                }

            } else {
                response.sendRedirect("register-otp.jsp?error=wrong");
            }

        } else {
            response.sendRedirect("register.jsp");
        }
    }
}
