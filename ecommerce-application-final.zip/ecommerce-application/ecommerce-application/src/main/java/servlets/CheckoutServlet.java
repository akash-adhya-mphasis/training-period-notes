package servlets;

import java.io.IOException;
import java.sql.*;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.CartDAO;
import model.CartItem;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/e_commerce_app", "root", "root@39");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer uid         = (Integer) session.getAttribute("id");
        String  uname       = (String)  session.getAttribute("uname");
        String  ctxPath     = request.getContextPath();

        // ── Guard: must be logged in ──────────────────────────
        if (uid == null) {
            response.sendRedirect(ctxPath + "/login.jsp?error=login_required");
            return;
        }

        // ── Load cart from DB ─────────────────────────────────
        CartDAO cartDAO = new CartDAO();
        List<CartItem> cart = cartDAO.getCartItems(uid);

        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(ctxPath + "/cart.jsp");
            return;
        }

        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false);

            // ── 1. Calculate totals ───────────────────────────
            double subtotal = 0;
            for (CartItem c : cart)
                subtotal += c.getPrice() * c.getQuantity();
            double shipping = subtotal > 499 ? 0 : 49;
            double total    = subtotal + shipping;

            // ── 2. Insert order ───────────────────────────────
            PreparedStatement orderPst = conn.prepareStatement(
                "INSERT INTO orders(user_id, total_amount, shipping, status) VALUES(?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );
            orderPst.setInt(1, uid);
            orderPst.setDouble(2, total);
            orderPst.setDouble(3, shipping);
            orderPst.setString(4, "Confirmed");
            orderPst.executeUpdate();

            ResultSet keys = orderPst.getGeneratedKeys();
            keys.next();
            int orderId = keys.getInt(1);

            // ── 3. Insert order_items + reduce product stock ──
            PreparedStatement itemPst = conn.prepareStatement(
                "INSERT INTO order_items(order_id, product_id, quantity, price) VALUES(?,?,?,?)"
            );
            PreparedStatement stockPst = conn.prepareStatement(
                "UPDATE products SET quantity = GREATEST(0, quantity - ?) WHERE p_id = ?"
            );

            for (CartItem c : cart) {
                itemPst.setInt(1, orderId);
                itemPst.setInt(2, c.getProductId());
                itemPst.setInt(3, c.getQuantity());
                itemPst.setDouble(4, c.getPrice());
                itemPst.executeUpdate();

                stockPst.setInt(1, c.getQuantity());
                stockPst.setInt(2, c.getProductId());
                stockPst.executeUpdate();
            }

            conn.commit();

            // ── 4. Clear DB cart ──────────────────────────────
            cartDAO.clearCart(uid);

            // ── 5. Reset cart badge to 0 ──────────────────────
            session.setAttribute("cartCount", 0);

            // ── 6. Store order snapshot in session for invoice ─
            session.setAttribute("lastOrderId",   orderId);
            session.setAttribute("lastOrderCart", cart);
            session.setAttribute("lastSubtotal",  subtotal);
            session.setAttribute("lastShipping",  shipping);
            session.setAttribute("lastTotal",     total);

            // ── 7. Go to invoice ──────────────────────────────
            response.sendRedirect(ctxPath + "/invoice.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            if (conn != null) try { conn.rollback(); } catch (Exception ignored) {}
            response.sendRedirect(ctxPath + "/cart.jsp?error=checkout_failed");
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.sendRedirect(req.getContextPath() + "/cart.jsp");
    }
}