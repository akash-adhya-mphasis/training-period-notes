package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CartDAO;

@WebServlet("/updateCart")
public class UpdateCart extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        Integer userId = (Integer) req.getSession().getAttribute("id");
        if (userId == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String action    = req.getParameter("action");    // "update" or "remove"
        int    productId = Integer.parseInt(req.getParameter("productId"));
        CartDAO dao      = new CartDAO();

        if ("remove".equals(action)) {
            dao.removeItem(userId, productId);
        } else {
            int qty = Integer.parseInt(req.getParameter("quantity"));
            dao.updateQuantity(userId, productId, qty);
        }

        res.sendRedirect(req.getContextPath() + "/cart.jsp");
    }
}
