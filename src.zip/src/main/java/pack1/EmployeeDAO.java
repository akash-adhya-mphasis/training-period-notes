package pack1;

import java.util.List;

public interface EmployeeDAO {
	void save(Employee e);		// create
	void update(Employee e);	// update
	void delete(int e);	// delete
	Employee getById(int id);	// Read one row
	List<Employee> getAll();	// Read all rows
}
