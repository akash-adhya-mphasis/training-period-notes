package pack1;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDAOJdbcTemplateImpl implements EmployeeDAO {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void save(Employee e) {
		String sql = "insert into emp values(?, ?, ?);";
		jdbcTemplate.update(sql, e.getId(), e.getName(), e.getSalary());
		System.out.println("Employee added");
	}
	
	public void update(Employee e) {
		String sql = "update emp set name=?, salary=?, where id=?;";
		jdbcTemplate.update(sql, e.getName(), e.getSalary(), e.getId());
		System.out.println("Employee updated");
	}
	
	public void delete(int id) {
		String sql = "delete from emp wehre id=?;";
		jdbcTemplate.update(sql, id);
		System.out.println("Employee deleted");
	}
	
	public Employee getById(int id) {
		String sql = "select * from emp where id=?;";
		return jdbcTemplate.queryForObject(sql, new EmployeeRowMapper(), id);
	}
	
	public List<Employee> getAll () {
		String sql = "select * from emp;";
		return jdbcTemplate.query(sql, new EmployeeRowMapper());
	}


}
