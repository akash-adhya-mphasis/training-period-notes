package com.example.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.example.service.Transaction;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/example/main/beans.xml");
		
		Transaction trns = ctx.getBean(Transaction.class);
		
		try {
			trns.transferMoney("akash");
			trns.transferMoney("kiran");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
