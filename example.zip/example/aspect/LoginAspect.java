package com.example.aspect;

import com.example.storage.UserStore;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.JoinPoint;


@Aspect
public class LoginAspect {
	
	@Before("execution(* com.example.service.*.*(..))")
	public void checkLogin(JoinPoint joinpoint) {
		
		Object[] args = joinpoint.getArgs();
		String username = (String) args[0];

		if(!UserStore.USERS.contains(username)) {
			throw new RuntimeException("Login failed! User not authorized: "+username);
		}
		
		System.out.println("Login successful for user: "+ username);
	}
}
