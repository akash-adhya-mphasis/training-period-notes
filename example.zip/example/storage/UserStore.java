package com.example.storage;

import java.util.ArrayList;
import java.util.List;

public class UserStore {
	
	public static final List<String> USERS = new ArrayList<>();
	
	static {
		USERS.add("admin");
		USERS.add("akash");
		USERS.add("suvra");
	}
}
