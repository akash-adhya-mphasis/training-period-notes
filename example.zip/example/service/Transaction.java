package com.example.service;

public class Transaction {
	
	public void transferMoney(String name) {
		System.out.println("Money transferred successfully for user: " + name);
	}
}
