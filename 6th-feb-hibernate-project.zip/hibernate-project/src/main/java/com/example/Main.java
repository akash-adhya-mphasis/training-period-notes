package com.example;

import org.hibernate.Transaction;
import org.hibernate.Session;


public class Main {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			
			Person p1 = new Person();
			p1.setName("Kiran");
			Passport ps1 = new Passport();
			ps1.setNumber("IND12345");
			p1.setPassport(ps1);
			
			
			Person p2 = new Person();
			p2.setName("Amit");

			Passport ps2 = new Passport();
			ps2.setNumber("IND67890");
			p2.setPassport(ps2);

			
			Person p3 = new Person();
			p3.setName("Sneha");
			Passport ps3 = new Passport();
			ps3.setNumber("IND54321");
			p3.setPassport(ps3);

			
			Person p4 = new Person();
			p4.setName("Ravi");
			Passport ps4 = new Passport();
			ps4.setNumber("IND98765");
			p4.setPassport(ps4);

			
			Person p5 = new Person();
			p5.setName("Priya");
			Passport ps5 = new Passport();
			ps5.setNumber("IND24680");
			p5.setPassport(ps5);

			
			Person p6 = new Person();
			p6.setName("Arjun");
			Passport ps6 = new Passport();
			ps6.setNumber("IND13579");
			p6.setPassport(ps6);
			
			session.save(p1);
			session.save(p2);
			session.save(p3);
			session.save(p4);
			session.save(p5);
			session.save(p6);
			
			tx.commit();
			System.out.println("Record saved successfully!");
			
			
		} catch(Exception e) {System.out.println(e.getMessage());}
		finally {
			session.close();
		}

	}

}
