package com.example;

import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.Session;

import java.util.List;



public class PrintData {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			
			Query<Person> q = session.createQuery("from Person", Person.class);
			List<Person> list = q.list();
			
			for(Person p: list) {
				System.out.println("Person Id: " + p.getPid());
				System.out.println("Name: " + p.getName());
				
				Passport ps = p.getPassport();
				if(ps != null) {
					System.out.println("Passport: " + ps.getNumber());
				}
			}
		} catch(Exception e) {}

	}

}
