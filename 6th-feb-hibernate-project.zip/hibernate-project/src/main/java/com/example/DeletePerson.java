package com.example;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class DeletePerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		
		try {
			tx = session.beginTransaction();
			
			Person p  = session.get(Person.class, 1);
			
			if(p != null) {
				session.delete(p);
				System.out.println("Record deleted successfully!");
			} else {
				System.out.println("Record not found");
			}
			
			tx.commit();
			
		} catch(Exception e) {}
	}

}
