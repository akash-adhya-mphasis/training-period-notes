package com.example;


import org.hibernate.Session;
import org.hibernate.Transaction;

public class UpdateData {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		
		Person p = session.get(Person.class, 3);	//existing id
		
		if(p != null) {
			p.setName("Kamal");
			
			Passport ps = p.getPassport();
			ps.setNumber("IND99999");
			
			System.out.println("Record Updated Successfully");
		} else {
			System.out.println("Record Not Found");
		}

	}

}
