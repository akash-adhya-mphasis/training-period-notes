package com.app.dao;

import java.util.List;

import com.app.model.Account;


public interface AccountDao {
	void update(Account a);
	Account getById(int id);
	List<Account> getAll();
}
