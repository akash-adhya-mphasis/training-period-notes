package com.app.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.app.model.Account;


public class AccountDaoImpl implements AccountDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public void update(Account a) {
			String sql = "update account set balance = ? where id = ?";
			jdbcTemplate.update(sql, a.getBalance(), a.getId());
			System.out.println("Balance updated!!");
	}

	@Override
	public Account getById(int id) {
		String sql = "select * from emp where id=?;";
		return jdbcTemplate.queryForObject(sql, new AccountRowMapper(), id);
	}

	@Override
	public List<Account> getAll() {
		String sql = "select * from account;";
		return jdbcTemplate.query(sql, new AccountRowMapper());
	}
	
}
