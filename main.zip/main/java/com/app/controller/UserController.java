package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class UserController {
	
    @RequestMapping("/accountinfo")
    public String showForm(Model model) {
    	System.out.println("int the controller");
        return "form";
    }
    
    @RequestMapping(value="/processform", method=RequestMethod.POST)
    public String processForm(@RequestParam("accno") String x,
			@RequestParam("amount") String y, Model ob) {
    	
    	ob.addAttribute("accno", x);
    	ob.addAttribute("amount", y);
    	
    	return null;
    }

}
