-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: e_commerce_app
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `p_id` int NOT NULL AUTO_INCREMENT,
  `p_name` varchar(100) NOT NULL,
  `category` varchar(25) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` int NOT NULL,
  `price` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Cotton T-Shirt','garments','Comfortable cotton t-shirt',100,499,'garments/t_shirt.jpg'),(2,'Denim Jeans','garments','Slim fit blue denim jeans',50,1299,'garments/Denim_Jeans.jpg'),(3,'Leather Jacket','garments','Stylish black leather jacket',20,3999,'garments/Leather_Jacket.jpg'),(4,'Formal Shirt','garments','White long-sleeve formal shirt',60,899,'garments/Formal_Shirt.jpg'),(5,'Summer Dress','garments','Floral printed summer dress',40,1499,'garments/Summer_Dress.jpg'),(6,'Sports Shorts','garments','Breathable running shorts',80,599,'garments/Sports_Shorts.jpg'),(7,'Wool Sweater','garments','Warm winter wool sweater',30,1999,'garments/Wool_Sweater.jpg'),(8,'Track Pants','garments','Comfortable track pants',70,799,'garments/Track_Pants.jpg'),(9,'Kurta','garments','Traditional cotton kurta',45,999,'garments/Kurta.jpg'),(10,'Blazer','garments','Formal office blazer',25,3499,'garments/Blazer.jpg'),(11,'Skirt','garments','Casual knee-length skirt',55,899,'garments/Skirt.jpg'),(12,'Hoodie','garments','Casual fleece hoodie',35,1599,'garments/Hoodie.jpg'),(13,'Smartphone','electronics','Android smartphone with 128GB storage',40,24999,'electronic/Smartphone.jpg'),(14,'Laptop','electronics','15-inch laptop with 8GB RAM',25,54999,'electronic/Laptop.jpg'),(15,'Bluetooth Speaker','electronics','Portable wireless speaker',60,2999,'electronic/Bluetooth_Speaker.jpg'),(16,'Smartwatch','electronics','Fitness tracking smartwatch',50,9999,'electronic/Smartwatch.jpg'),(17,'LED TV','electronics','42-inch LED television',15,32999,'electronic/LED_TV.jpg'),(18,'Headphones','electronics','Noise-cancelling headphones',70,4999,'electronic/Headphones.jpg'),(19,'Tablet','electronics','10-inch Android tablet',30,19999,'electronic/Tablet.jpg'),(20,'Gaming Console','electronics','Latest gaming console',10,45999,'electronic/Gaming_Console.jpg'),(21,'Digital Camera','electronics','DSLR camera with 24MP lens',12,37999,'electronic/Digital_Camera.jpg'),(22,'Microwave Oven','electronics','800W microwave oven',20,8999,'electronic/Microwave_Oven.jpg'),(23,'Power Bank','electronics','10000mAh portable charger',90,1999,'electronic/Power_Ban.jpg'),(24,'Wireless Mouse','electronics','Ergonomic wireless mouse',100,999,'electronic/Wireless_Mouse.jpg'),(25,'The Great Gatsby','books','Classic novel by F. Scott Fitzgerald',50,499,'books/The_Great_Gatsby.jpg'),(26,'1984','books','Dystopian novel by George Orwell',60,400,'books/1984.jpg'),(27,'To Kill a Mockingbird','books','Novel by Harper Lee',40,449,'books/To_Kill_a_Mockingbird.jpg'),(28,'The Alchemist','books','Inspirational novel by Paulo Coelho',70,299,'books/The_Alchemist.jpg'),(29,'Harry Potter','books','Fantasy novel by J.K. Rowling',80,599,'books/Harry_Potter.jpg'),(30,'The Hobbit','books','Fantasy novel by J.R.R. Tolkien',45,549,'books/The_Hobbi.jpg'),(31,'Pride and Prejudice','books','Romantic novel by Jane Austen',35,399,'books/Pride_and_Prejudice.jpg'),(32,'Atomic Habits','books','Self-help book by James Clear',55,699,'books/Atomic_Habits.jpg'),(33,'Rich Dad Poor Dad','books','Finance book by Robert Kiyosaki',65,499,'books/Rich_Dad_Poor_Dad.jpg'),(34,'Sapiens','books','History book by Yuval Noah Harari',40,799,'books/Sapiens.jpg'),(35,'The Lean Startup','books','Business book by Eric Ries',30,699,'books/The_Lean_Startup.jpg'),(36,'Think and Grow Rich','books','Motivational book by Napoleon Hill',50,399,'books/Think_and_Grow_Rich.jpg'),(37,'Chocolate Bar','food','Milk chocolate bar',200,99,'Food/Chocolate_Bar.jpg'),(38,'Potato Chips','food','Crispy salted potato chips',150,149,'Food/Potato_Chips.jpg'),(39,'Instant Noodles','food','Pack of instant noodles',180,49,'Food/Instant_Noodles.jpg'),(40,'Coffee Powder','food','Premium roasted coffee powder',80,299,'Food/Coffee_Powder.jpg'),(41,'Green Tea','food','Organic green tea bags',90,249,'Food/Green_Tea.jpg'),(42,'Biscuits','food','Pack of butter biscuits',120,99,'Food/Biscuits.jpg'),(43,'Fruit Juice','food','1L mixed fruit juice',100,149,'Food/Fruit_Juice.jpg'),(44,'Breakfast Cereal','food','Corn flakes cereal',70,199,'Food/Breakfast_Cereal.jpg'),(45,'Pasta','food','Italian durum wheat pasta',85,149,'Food/Pasta.jpg'),(46,'Rice','food','5kg basmati rice pack',60,499,'Food/Rice.jpg'),(47,'Cooking Oil','food','1L sunflower oil',75,199,'Food/Cooking_Oil.jpg'),(48,'Ice Cream','food','500ml vanilla ice cream tub',50,249,'Food/Ice_Cream.jpg'),(49,'Cheese','food','200g cheddar cheese block',40,299,'Food/Cheese.jpg'),(50,'Bread','food','Whole wheat bread loaf',100,79,'Food/Bread.jpg');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-16 10:36:36
